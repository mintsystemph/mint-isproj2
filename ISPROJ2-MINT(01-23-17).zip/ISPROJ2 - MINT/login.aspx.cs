﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (!IsPostBack)
            {
                if (int.Parse(Session["typeid"].ToString()) == 7)
                {
                    Response.Redirect("Customer/index.aspx");
                }
                else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
                {
                    Response.Redirect("Madras/index.aspx");
                }
            }
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT UserID, TypeID, Status FROM Users WHERE Email=@email AND Password=@password";
        com.Parameters.AddWithValue("@email", txtEmail.Text);
        com.Parameters.AddWithValue("@password", HelpConfig.CreateSHAHash(txtPassword.Text));

        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            string status = "";
            string userid = "";
            string typeid = "";

            while (dr.Read())
            {
                userid = dr["UserID"].ToString();
                typeid = dr["TypeID"].ToString();
                status = dr["Status"].ToString();
            }

            if (status == "Active")
            {
                Session["userid"] = userid;
                Session["typeid"] = typeid;
                con.Close();

                if (int.Parse(Session["typeid"].ToString()) == 7)
                {
                    Response.Redirect("Customer/index.aspx");
                }

                else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
                {
                    Response.Redirect("Madras/index.aspx");
                }
            }

            else if (status == "Unverified")
            {
                con.Close();

                lblInvalid.Visible = false;
                lblExpired.Visible = false;
                lblUnverified.Visible = true;
            }

            else if (status == "Inactive")
            {
                con.Close();

                lblInvalid.Visible = false;
                lblUnverified.Visible = false;
                lblExpired.Visible = true;
            }
        }

        else
        {
            con.Close();
            lblUnverified.Visible = false;
            lblExpired.Visible = false;
            lblInvalid.Visible = true;
        }
    }

}