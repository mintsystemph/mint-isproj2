﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Data;
using System.Data.SqlClient;
using Twilio;

/// <summary>
/// Summary description for HelpConfig
/// </summary>
public class HelpConfig
{
	public HelpConfig()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static string GetCon()
    {
        //accesing web.config
        //looking at the connection string
        return ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
    }

    public static string CreateSHAHash(string Phrase)
    {
        SHA512Managed HashTool = new SHA512Managed();
        Byte[] PhraseAsByte = System.Text.Encoding.UTF8.GetBytes(string.Concat(Phrase));
        Byte[] EncryptedBytes = HashTool.ComputeHash(PhraseAsByte);
        HashTool.Clear();
        return Convert.ToBase64String(EncryptedBytes);
    }

    public static string randomizer()
    {
        char[] chars = new char[62];
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
        byte[] data = new byte[1];

        using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
        {
            crypto.GetNonZeroBytes(data);
            data = new byte[8];
            crypto.GetNonZeroBytes(data);
        }

        StringBuilder result = new StringBuilder(8);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length)]);
        }

        return result.ToString();
    }

    public static void SendEmail(string email, string subject, string message)
    {
        using (MailMessage mm = new MailMessage("minstystemph@gmail.com", email))
        {
            mm.Subject = subject;
            mm.Body = message;
            mm.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;

            NetworkCredential NetworkCred = new NetworkCredential("mintsystemph@gmail.com", "peppermintos");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
        }
    }

    public static void SendSMS(string mobile, string message)
    {
        string AccountSid = "ACb545a28d19ba95f833897efa4b45c0bc";
        string AuthToken = "7f7b420b0630830e97f85d49b01152ed";

        var client = new TwilioRestClient(AccountSid, AuthToken);

        client.SendMessage("+12407529955", mobile, message);
    }

    public static string CountData(string table, string status)
    {
        SqlConnection con = new SqlConnection(GetCon());
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;

        if (status == "")
        {
            com.CommandText = "SELECT COUNT(*) FROM " + table;
        }
        else
        {
            com.CommandText = "SELECT COUNT(*) FROM " + table + " WHERE Status=@Status";
            com.Parameters.AddWithValue("@Status", status);
        }
        int total = (int)com.ExecuteScalar();
        con.Close();
        return total.ToString();
    }
}