﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class MADRAS_Materials_addrawmaterial : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }
            else if (int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                if (int.Parse(Session["typeid"].ToString()) == 7)
                {
                    Response.Redirect("~/Madras/index.aspx");
                }
            }
            else if (int.Parse(Session["typeid"].ToString()) == 1)
            {
                if (!IsPostBack)
                {
                    GetMaterials();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetMaterials()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT MaterialID, MaterialName FROM RawMaterials WHERE HasVariant=@HasVariant";
        com.Parameters.AddWithValue("@HasVariant", "Yes");
        SqlDataReader dr = com.ExecuteReader();
        ddlMaterial.DataSource = dr;
        ddlMaterial.DataTextField = "MaterialName";
        ddlMaterial.DataValueField = "MaterialID";
        ddlMaterial.DataBind();
        con.Close();

        ddlMaterial.Items.Insert(0, new ListItem("Select a material...", ""));
    }

    protected void chHasVariant_CheckedChanged(object sender, EventArgs e)
    {
        if (chHasVariant.Checked)
        {
            pnlImage.Visible = false;
        }

        else
        {
            pnlImage.Visible = true;
        }
    }

    protected void NewMaterial_Click(object sender, EventArgs e)
    {
        pnlShowAddMaterial.Visible = true;
    }

    protected void NewVar_Click(object sender, EventArgs e)
    {
        pnlShowAddVar.Visible = true;
    }

    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        if (txtMName.Text == "" || txtDescription.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Fill out all necessary details. Try again.');", true);
        }

        else
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT MaterialName FROM RawMaterials WHERE MaterialName=@MaterialName";
            com.Parameters.AddWithValue("@MaterialName", txtMName.Text);

            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                con.Close();

                txtMName.Text = "";
                txtDescription.Text = "";

                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = false;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Raw material is already existing. Try again.');", true);
            }

            else
            {
                string hasVariant = "";

                if (chHasVariant.Checked)
                {
                    hasVariant = "Yes";
                }

                else
                {
                    hasVariant = "No";
                }

                con.Close();

                con.Open();
                SqlCommand com2 = new SqlCommand();
                com2.Connection = con;
                com2.CommandText = "INSERT INTO RawMaterials VALUES (@MaterialName, @MaterialType, @Measurement, @MaterialDescription, @HasVariant); " +
                                "SELECT TOP 1 MaterialID FROM RawMaterials ORDER BY MaterialID DESC;";
                com2.Parameters.AddWithValue("@MaterialName", txtMName.Text);
                com2.Parameters.AddWithValue("@MaterialType", ddlTypes.SelectedValue);
                com2.Parameters.AddWithValue("@Measurement", ddlMeasurement.SelectedValue);
                com2.Parameters.AddWithValue("@MaterialDescription", txtDescription.Text);
                com2.Parameters.AddWithValue("@HasVariant", hasVariant);
                int materialID = (int)com2.ExecuteScalar();
                con.Close();

                if (chHasVariant.Checked == false)
                {
                    con.Open();
                    SqlCommand com3 = new SqlCommand();
                    com3.Connection = con;
                    com3.CommandText = "INSERT INTO MaterialDetails (MaterialID, Status, Image, DateAdded) VALUES (@MaterialID, @Status, @Image, @DateAdded)";
                    com3.Parameters.AddWithValue("@MaterialID", materialID);
                    com3.Parameters.AddWithValue("@Status", "Active");

                    if (fulImage.HasFile)
                    {
                        string fileExt = Path.GetExtension(fulImage.FileName);
                        string id = Guid.NewGuid().ToString();
                        com3.Parameters.AddWithValue("@Image", id + fileExt);
                        fulImage.SaveAs(Server.MapPath("~/img/materials/" + id + fileExt));
                    }

                    else
                    {
                        com3.Parameters.AddWithValue("@Image", DBNull.Value);
                    }

                    com3.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                    com3.ExecuteNonQuery();
                    con.Close();
                }

                txtMName.Text = "";
                txtDescription.Text = "";
                chHasVariant.Checked = true;

                GetMaterials();

                pnlShowAddMaterial.Visible = false;
                lblSuccessAddVar.Visible = false;
                lblSuccessAdd.Visible = true;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Raw material successfully added!');", true);
            }
        }
    }

    protected void btnAddVariant_Click(object sender, EventArgs e)
    {
        if (txtColor.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Enter color type of variant. Try again.');", true);
        }

        else
        {
            if (ddlMaterial.SelectedValue == "")
            {
                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = false;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Please select a raw material to add a variant.')", true);
            }

            else
            {
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandText = "INSERT INTO MaterialDetails (MaterialID, Color, Status, Image, DateAdded) VALUES (@MaterialID, @Color, @Status, @Image, @DateAdded)";
                com.Parameters.AddWithValue("@MaterialID", ddlMaterial.SelectedValue);
                com.Parameters.AddWithValue("@Color", txtColor.Text);
                com.Parameters.AddWithValue("@Status", "Active");

                if (fulImageVariant.HasFile)
                {
                    string fileExt = Path.GetExtension(fulImageVariant.FileName);
                    string id = Guid.NewGuid().ToString();
                    com.Parameters.AddWithValue("@Image", id + fileExt);
                    fulImageVariant.SaveAs(Server.MapPath("~/img/materials/" + id + fileExt));
                }

                else
                {
                    com.Parameters.AddWithValue("@Image", DBNull.Value);
                }

                com.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                com.ExecuteNonQuery();
                con.Close();

                txtColor.Text = "";

                GetMaterials();

                pnlShowAddVar.Visible = false;
                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = true;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Raw material variant successfully added! You may now add its inventory.');", true);
            }
        }
    }

    protected void btnHideAddNew_Click(object sender, EventArgs e)
    {
        lblSuccessAdd.Visible = false;
        lblSuccessAddVar.Visible = false;
        pnlShowAddMaterial.Visible = false;
    }

        protected void btnHideVariant_Click(object sender, EventArgs e)
    {
        lblSuccessAdd.Visible = false;
        lblSuccessAddVar.Visible = false;
        pnlShowAddVar.Visible = false;
    }
}