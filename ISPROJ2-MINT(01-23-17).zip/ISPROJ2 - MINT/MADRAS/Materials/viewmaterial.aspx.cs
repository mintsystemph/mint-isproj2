﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;


public partial class MADRAS_Materials_viewmaterial : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }
            else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                if (!IsPostBack)
                {
                    GetMaterials();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetMaterials()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT rm.MaterialID, md.MDetailsID, md.Image, rm.MaterialName, md.Color, rm.MaterialType, rm.Measurement, rm.MaterialDescription, md.DateAdded, md.DateModified " + 
                        "FROM RawMaterials rm INNER JOIN MaterialDetails md ON rm.MaterialID=md.MaterialID WHERE md.Status=@Status ORDER BY rm.HasVariant DESC";
        com.Parameters.AddWithValue("@Status", "Active");
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "RawMaterials");
        lvMaterials.DataSource = ds;
        lvMaterials.DataBind();
        con.Close();
    }
    
    void GetInfo(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT rm.MaterialID, md.MDetailsiD, md.Image, rm.MaterialName, md.Color, rm.MaterialType, rm.Measurement, rm.MaterialDescription " +
                        "FROM RawMaterials rm INNER JOIN MaterialDetails md ON rm.MaterialID=md.MaterialID WHERE md.MDetailsID=@MDetailsID ";
        com.Parameters.AddWithValue("@MDetailsID", ID);

        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                ltMaterialID.Text = dr["MaterialID"].ToString();
                ltMDetailsID.Text = dr["MDetailsID"].ToString();

                if (dr["Image"].ToString() == "")
                {
                    pnlImage.Visible = false;
                    btnRemoveImage.Visible = false;
                    pnlFulImage.Visible = true;
                }
                else
                {
                    pnlFulImage.Visible = false;
                    pnlImage.Visible = true;
                    btnRemoveImage.Visible = true;
                    imgMaterial.ImageUrl = "~/img/materials/" + dr["Image"].ToString();
                }

                txtMaterialName.Text = dr["MaterialName"].ToString();
                txtColor.Text = dr["Color"].ToString();
                ddlTypes.SelectedValue = dr["MaterialType"].ToString();
                ddlMeasurement.SelectedValue = dr["Measurement"].ToString();
                txtMaterialDescription.Text = dr["MaterialDescription"].ToString();
            }

            con.Close();

            if (txtColor.Text == "")
            {
                pnlColor.Visible = false;
            }
            else
            {
                pnlColor.Visible = true;
            }
        }

        else
        {
            con.Close();
            Response.Redirect("viewmaterial.aspx");
        }
    }

    void ArchiveRecord(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE MaterialDetails SET Status=@Status, DateModified=@DateModified WHERE MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@MDetailsID", ID);
        com.Parameters.AddWithValue("@Status", "Inactive");
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();
    }

    protected void lvMaterials_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());

        if (e.CommandName == "modify")
        {
            GetInfo(id);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "myModal", "showPopup();", true);
        }

        if (e.CommandName == "remove")
        {
            ArchiveRecord(id);
            GetMaterials();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Raw material was removed successfully!');", true);
        }
    }

    protected void btnRemoveImage_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE MaterialDetails SET Image=@Image, DateModified=@DateModified WHERE MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@MDetailsID", ltMDetailsID.Text);
        com.Parameters.AddWithValue("@Image", DBNull.Value);
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();

        GetMaterials();

        ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Image removed successfully!');", true);
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (txtMaterialName.Text == "" || txtMaterialDescription.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Please fill out the necessary details.');", true);
        }

        else
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "UPDATE RawMaterials SET MaterialName=@MaterialName, MaterialType=@MaterialType, Measurement=@Measurement, " + 
                            "MaterialDescription=@MaterialDescription WHERE MaterialID=@MaterialID";
            com.Parameters.AddWithValue("@MaterialID", ltMaterialID.Text);
            com.Parameters.AddWithValue("@MaterialName", txtMaterialName.Text);
            com.Parameters.AddWithValue("@MaterialType", ddlTypes.SelectedValue);
            com.Parameters.AddWithValue("@Measurement", ddlMeasurement.SelectedValue);
            com.Parameters.AddWithValue("@MaterialDescription", txtMaterialDescription.Text);
            com.ExecuteNonQuery();

            con.Close();

            if (pnlFulImage.Visible)
            {
                con.Open();
                SqlCommand com2 = new SqlCommand();
                com2.Connection = con;
                com2.CommandText = "UPDATE MaterialDetails SET Image=@Image, DateModified=@DateModified WHERE MDetailsID=@MDetailsID";
                com2.Parameters.AddWithValue("@MDetailsID", ltMDetailsID.Text);

                if (fulImage.HasFile)
                {
                    string fileExt = Path.GetExtension(fulImage.FileName);
                    string id = Guid.NewGuid().ToString();
                    com2.Parameters.AddWithValue("@Image", id + fileExt);
                    fulImage.SaveAs(Server.MapPath("~/img/materials/" + id + fileExt));
                }

                else
                {
                    com2.Parameters.AddWithValue("@Image", DBNull.Value);
                }

                com2.Parameters.AddWithValue("@DateModified", DateTime.Now);
                com2.ExecuteNonQuery();

                con.Close();
            }

            GetMaterials();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Material details were updated successfully!');", true);
        }
    }
}