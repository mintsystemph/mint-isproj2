﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class MADRAS_Users_Employees_viewemployees : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 1)
            {
                if (!IsPostBack)
                {
                    GetEmployees();
                }
            }
        }
        
        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetEmployees()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT u.UserID, t.UserType, u.FirstName + ' ' + u.LastName AS Name, u.Email, u.Mobile, u.Telephone, u.DateAdded, u.DateModified FROM Users u INNER JOIN UserTypes t " + 
                        "on u.TypeID=t.TypeID WHERE UserType != @UserType AND Status=@Status";
        com.Parameters.AddWithValue("@UserType", "Customer");
        com.Parameters.AddWithValue("@Status", "Active");
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "Users");
        lvEmployees.DataSource = ds;
        lvEmployees.DataBind();

        con.Close();
    }

    void GetUserTypes()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT TypeID, UserType FROM UserTypes WHERE UserType != @UserType";
        com.Parameters.AddWithValue("@UserType", "Customer");
        SqlDataReader dr = com.ExecuteReader();
        ddlTypes.DataSource = dr;
        ddlTypes.DataTextField = "UserType";
        ddlTypes.DataValueField = "TypeID";
        ddlTypes.DataBind();
        con.Close();
        
        ddlTypes.Items.Insert(0, new ListItem("Select a user type...", ""));
    }

    void GetInfo(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT u.UserID, t.TypeID, u.FirstName, u.LastName, u.Email, u.Mobile, u.Telephone FROM Users u " + 
                        "INNER JOIN UserTypes t on u.TypeID=t.TypeID WHERE u.UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ID);

        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                ltUserID.Text = dr["UserID"].ToString();
                ddlTypes.SelectedValue = dr["TypeID"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtFirstName.Text = dr["FirstName"].ToString();
                txtLastName.Text = dr["LastName"].ToString();
                txtMobile.Text = dr["Mobile"].ToString();
                txtTelephone.Text = dr["Telephone"].ToString();
            }
            con.Close();
        }

        else
        {
            con.Close();
            Response.Redirect("viewemployees.aspx");
        }
    }

    void ArchiveRecord(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Users SET Status=@Status, DateModified=@DateModified WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ID);
        com.Parameters.AddWithValue("@Status", "Inactive");
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();
    }

    protected void lvEmployees_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());

        if (e.CommandName == "modify")
        {
            GetInfo(id);
            GetUserTypes();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "myModal", "showPopup();", true);

        }

        if (e.CommandName == "remove")
        {
            ArchiveRecord(id);
            GetEmployees();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                    "alert('Employee was removed successfully!');", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Users SET TypeID=@TypeID, DateModified=@DateModified WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ltUserID.Text);
        com.Parameters.AddWithValue("@TypeID", ddlTypes.SelectedValue);
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();
        
        con.Close();
        
        GetEmployees();
        
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Employee details were updated successfully!');", true);
    }
}