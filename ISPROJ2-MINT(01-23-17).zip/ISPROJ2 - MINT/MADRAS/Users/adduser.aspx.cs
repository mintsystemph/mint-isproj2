﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class MADRAS_adduser : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 1)
            {
                if (!IsPostBack)
                {
                    GetUserTypes();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetUserTypes()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT TypeID, UserType FROM UserTypes";
        SqlDataReader dr = com.ExecuteReader();
        ddlTypes.DataSource = dr;
        ddlTypes.DataTextField = "UserType";
        ddlTypes.DataValueField = "TypeID";
        ddlTypes.DataBind();
        con.Close();

        ddlTypes.Items.Insert(0, new ListItem("Select a user type...", ""));
    }

    protected void ddlTypes_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlTypes.SelectedItem.ToString() == "Customer")
        {
            lblFName.Visible = false;
            pnlCustomer.Visible = true;
            lblContactPerson.Visible = true;

            lblLName.ForeColor = System.Drawing.Color.White;
            lblLName.Attributes.Remove("style");
            txtFName.Attributes.Add("placeholder", "First Name");
            txtLName.Attributes.Add("placeholder", "Last Name");
        }

        else
        {
            pnlCustomer.Visible = false;
            lblContactPerson.Visible = false;
            lblFName.Visible = true;

            lblLName.ForeColor = System.Drawing.Color.Empty;
            lblLName.Attributes.Remove("style");
            txtFName.Attributes.Remove("placeholder");
            txtLName.Attributes.Remove("placeholder");
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        if (ddlTypes.SelectedValue == "")
        {
            lblErrorEmail.Visible = false;
            lblErrorMobile.Visible = false;
            lblErrorMobile2.Visible = false;
            lblErrorType.Visible = true;
        }

        else if (txtMobile.Text == "+63")
        {
            lblErrorEmail.Visible = false;
            lblErrorType.Visible = false;
            lblErrorMobile.Visible = false;
            lblErrorMobile2.Visible = true;

            txtMobile.Focus();
        }

        else
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT Email FROM Users WHERE Email=@Email";
            com.Parameters.AddWithValue("@Email", txtEmail.Text);

            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                con.Close();
                lblErrorType.Visible = false;
                lblErrorMobile.Visible = false;
                lblErrorMobile2.Visible = false;
                lblErrorEmail.Visible = true;

                txtEmail.Text = "";
                txtEmail.Focus();
            }

            else
            {
                con.Close();

                con.Open();
                SqlCommand com2 = new SqlCommand();
                com2.Connection = con;
                com2.CommandText = "SELECT Mobile FROM Users WHERE Mobile=@Mobile";
                com2.Parameters.AddWithValue("@Mobile", txtMobile.Text);

                SqlDataReader dr2 = com2.ExecuteReader();
                if (dr2.HasRows)
                {
                    con.Close();
                    lblErrorEmail.Visible = false;
                    lblErrorType.Visible = false;
                    lblErrorMobile2.Visible = false;
                    lblErrorMobile.Visible = true;

                    txtMobile.Text = "+63";
                    txtMobile.Focus();
                }

                else
                {
                    if (txtPhone.Text == "")
                    {
                        txtPhone.Text = DBNull.Value.ToString();
                    }

                    con.Close();

                    lblErrorEmail.Visible = false;
                    lblErrorType.Visible = false;
                    lblErrorMobile.Visible = false;
                    lblErrorMobile2.Visible = false;
                    
                    string name = txtFName.Text + " " + txtLName.Text;

                    string subject = "New Account Created";
                    string uniqueKey = "R" + HelpConfig.randomizer() + DateTime.Now.ToString("yyyyMMdd");

                    string message = "Hello " + name + ", you have been given access to the MINT System by the administrator. <br />" +
                                            "Please click to this <a href='" + Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath +
                                            @"resetpassword.aspx?uk=" + uniqueKey + "'>link</a> to confirm and complete the creation of your account.<br />" +
                                            "This is a one-time link. It cannot be opened again once it has been clicked. Thank you. <br /><br />" +
                                            "This message is auto-generated by the MINT system. Do not reply.";

                    HelpConfig.SendEmail(txtEmail.Text, subject, message);
                    
                    con.Open();
                    SqlCommand com3 = new SqlCommand();
                    com3.Connection = con;
                    com3.CommandText = "INSERT INTO Users VALUES (@TypeID, @Email, @Password, @FirstName, " +
                                    " @LastName, @Mobile, @Telephone, @Status, @DateAdded, @DateModified); " +
                                    "SELECT TOP 1 UserID FROM Users ORDER BY UserID DESC;";
                    com3.Parameters.AddWithValue("@TypeID", ddlTypes.SelectedValue);
                    com3.Parameters.AddWithValue("@Email", txtEmail.Text);
                    com3.Parameters.AddWithValue("@Password", "None yet");
                    com3.Parameters.AddWithValue("@FirstName", txtFName.Text);
                    com3.Parameters.AddWithValue("@LastName", txtLName.Text);
                    com3.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    com3.Parameters.AddWithValue("@Telephone", txtPhone.Text);
                    com3.Parameters.AddWithValue("@Status", "Unverified");
                    com3.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                    com3.Parameters.AddWithValue("@DateModified", DBNull.Value);

                    int userID = (int)com3.ExecuteScalar();

                    con.Close();

                    if (pnlCustomer.Visible == true)
                    {
                        con.Open();
                        SqlCommand comx = new SqlCommand();
                        comx.Connection = con;
                        comx.CommandText = "INSERT INTO Customers VALUES (@UserID, @CompanyName, @PaymentTerms)";
                        comx.Parameters.AddWithValue("@UserID", userID);
                        comx.Parameters.AddWithValue("@CompanyName", txtCompanyName.Text);
                        comx.Parameters.AddWithValue("@PaymentTerms", DBNull.Value);
                        comx.ExecuteNonQuery();
                        con.Close();
                    }

                    con.Open();
                    SqlCommand com4 = new SqlCommand();
                    com4.Connection = con;
                    com4.CommandText = "INSERT INTO NotifLink VALUES (@UserID, @SupplierID, @UniqueKey, @NotifType, @Subject, @Message, @Status, @DateAdded, @DateClicked)";
                    com4.Parameters.AddWithValue("@UserID", userID);
                    com4.Parameters.AddWithValue("@SupplierID", DBNull.Value);
                    com4.Parameters.AddWithValue("@UniqueKey", uniqueKey);
                    com4.Parameters.AddWithValue("@NotifType", "Registration");
                    com4.Parameters.AddWithValue("@Subject", subject);
                    com4.Parameters.AddWithValue("@Message", message);
                    com4.Parameters.AddWithValue("@Status", "Unclicked");
                    com4.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                    com4.Parameters.AddWithValue("@DateClicked", DBNull.Value);
                    com4.ExecuteNonQuery();

                    con.Close();

                    GetUserTypes();
                    txtEmail.Text = "";
                    txtCompanyName.Text = "";
                    txtFName.Text = "";
                    txtLName.Text = "";
                    txtMobile.Text = "+63";
                    txtPhone.Text = "";

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                            "alert('Account created! An email has been sent to the user to complete the registration. Inform the user immediately. Thank you.');", true);
                }
            }
        }
    }
}