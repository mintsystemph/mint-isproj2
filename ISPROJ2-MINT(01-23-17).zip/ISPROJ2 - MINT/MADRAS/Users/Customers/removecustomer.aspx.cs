﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class MADRAS_Users_Customers_removecustomer : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["ID"] != null)
        {
            if (Session["userid"] != null)
            {
                if (!IsPostBack)
                {
                    if (int.Parse(Session["typeid"].ToString()) == 7)
                    {
                        Response.Redirect("~/Customer/index.aspx");
                    }
                    else if (int.Parse(Session["typeid"].ToString()) == 2 || int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                        int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
                    {
                        Response.Redirect("~/Madras/index.aspx");
                    }

                    else if (int.Parse(Session["typeid"].ToString()) == 1)
                    {
                        int ID = 0;
                        bool validID = int.TryParse(Request.QueryString["ID"].ToString(), out ID);

                        if (validID)
                        {
                            if (!IsPostBack)
                            {
                                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "confirm ('You are about to remove a customer. Would you like to continue?');", true);
                                ArchiveRecord(ID);
                            }
                        }
                    }
                }
            }
        }
        else
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }
            else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }
        }
    }

    void ArchiveRecord(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Users SET Status=@Status WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ID);
        com.Parameters.AddWithValue("@Status", "Inactive");
        com.ExecuteNonQuery();

        con.Close();

        Response.Redirect("viewcustomers.aspx");
    }
}