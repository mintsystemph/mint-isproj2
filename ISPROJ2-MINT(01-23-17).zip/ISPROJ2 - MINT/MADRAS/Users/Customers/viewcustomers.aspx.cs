﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class MADRAS_Users_Customers_viewcustomers : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 2 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 3)
            {
                if (!IsPostBack)
                {
                    GetCustomers();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetCustomers()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT u.UserID, c.CompanyName, u.FirstName + ' ' + u.LastName AS ContactPerson, u.Email, u.Mobile, u.Telephone, c.PaymentTerms, " + 
                        "u.DateAdded, u.DateModified FROM Users u INNER JOIN Customers c on u.UserID=c.UserID INNER JOIN UserTypes t ON u.TypeID=t.TypeID " +
                        "WHERE t.UserType=@UserType AND u.Status=@Status";
        com.Parameters.AddWithValue("@UserType", "Customer");
        com.Parameters.AddWithValue("@Status", "Active");
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "Users");
        lvCustomers.DataSource = ds;
        lvCustomers.DataBind();

        con.Close();
    }

    void GetBranches(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT BranchName, DeliveryAddress FROM Branches WHERE CustomerID=@CustomerID";
        com.Parameters.AddWithValue("@CustomerID", ID);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "Branches");
        lvBranches.DataSource = ds;
        lvBranches.DataBind();

        con.Close();
    }

    void GetInfo(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT c.CustomerID, c.CompanyName, u.Email, u.Mobile, u.Telephone, c.PaymentTerms FROM Customers c INNER JOIN " + 
                        "Users u ON c.UserID=u.UserID WHERE c.UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ID);

        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                ltCustomerID.Text = dr["CustomerID"].ToString();
                lblCompanyName.Text = dr["CompanyName"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtMobile.Text = dr["Mobile"].ToString();
                txtTelephone.Text = dr["Telephone"].ToString();
                txtPaymentTerms.Text = dr["PaymentTerms"].ToString();
            }
            con.Close();

            ltUserID.Text = ID.ToString();
        }

        else
        {
            con.Close();
            Response.Redirect("viewcustomers.aspx");
        }
    }

    void ArchiveRecord(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Users SET Status=@Status, DateModified=@DateModified WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ID);
        com.Parameters.AddWithValue("@Status", "Inactive");
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();
    }

    protected void lvCustomers_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());

        if (e.CommandName == "modify")
        {
            GetInfo(id);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "myModal", "showPopup();", true);

        }

        if (e.CommandName == "remove")
        {
            ArchiveRecord(id);
            GetCustomers();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                    "alert('Customer was removed successfully!');", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Customers SET PaymentTerms=@PaymentTerms WHERE UserID=@UserID; " + 
                        "UPDATE Users SET DateModified=@DateModified WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", ltUserID.Text);
        com.Parameters.AddWithValue("@PaymentTerms", txtPaymentTerms.Text);
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();

        GetCustomers();

        ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Customer details were updated successfully!');", true);
    }
}