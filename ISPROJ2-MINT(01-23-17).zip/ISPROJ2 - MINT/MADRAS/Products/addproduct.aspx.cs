﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class MADRAS_Products_addproduct : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 2 ||
                    int.Parse(Session["typeid"].ToString()) == 3 || int.Parse(Session["typeid"].ToString()) == 4 ||
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 1)
            {
                if (!IsPostBack)
                {
                    GetProducts();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetProducts()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT ProductID, ProductName FROM Products WHERE HasVariant=@HasVariant";
        com.Parameters.AddWithValue("@HasVariant", "Yes");
        SqlDataReader dr = com.ExecuteReader();
        ddlProduct.DataSource = dr;
        ddlProduct.DataTextField = "ProductName";
        ddlProduct.DataValueField = "ProductID";
        ddlProduct.DataBind();
        con.Close();

        ddlProduct.Items.Insert(0, new ListItem("Select a product...", ""));
    }

    protected void chHasVariant_CheckedChanged(object sender, EventArgs e)
    {
        if (chHasVariant.Checked)
        {
            pnlImage.Visible = false;
        }

        else
        {
            pnlImage.Visible = true;
        }
    }

    protected void NewProd_Click(object sender, EventArgs e)
    {
        pnlShowAddProd.Visible = true;
    }

    protected void NewVar_Click(object sender, EventArgs e)
    {
        pnlShowAddVar.Visible = true;
    }

    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        if (txtPName.Text == "" || txtDescription.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Fill out all necessary details. Try again.');", true);
        }

        else
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT ProductName FROM Products WHERE ProductName=@ProductName";
            com.Parameters.AddWithValue("@ProductName", txtPName.Text);

            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                con.Close();

                txtPName.Text = "";
                txtDescription.Text = "";

                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = false;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Product is already existing. Try again.');", true);
            }
            else
            {
                string hasVariant = "";

                if (chHasVariant.Checked)
                {
                    hasVariant = "Yes";
                }

                else
                {
                    hasVariant = "No";
                }

                con.Close();

                con.Open();
                SqlCommand com2 = new SqlCommand();
                com2.Connection = con;
                com2.CommandText = "INSERT INTO Products VALUES (@ProductName, @ProductType, @ProductDescription, @HasVariant); " +
                                "SELECT TOP 1 ProductID FROM Products ORDER BY ProductID DESC;";
                com2.Parameters.AddWithValue("@ProductName", txtPName.Text);
                com2.Parameters.AddWithValue("@ProductType", ddlTypes.SelectedValue);
                com2.Parameters.AddWithValue("@ProductDescription", txtDescription.Text);
                com2.Parameters.AddWithValue("@HasVariant", hasVariant);
                int productID = (int)com2.ExecuteScalar();
                con.Close();

                if (chHasVariant.Checked == false)
                {
                    con.Open();
                    SqlCommand com3 = new SqlCommand();
                    com3.Connection = con;
                    com3.CommandText = "INSERT INTO ProductDetails (ProductID, Status, Image, DateAdded) VALUES (@ProductID, @Status, @Image, @DateAdded)";
                    com3.Parameters.AddWithValue("@ProductID", productID);
                    com3.Parameters.AddWithValue("@Status", "Active");

                    if (fulImage.HasFile)
                    {
                        string fileExt = Path.GetExtension(fulImage.FileName);
                        string id = Guid.NewGuid().ToString();
                        com3.Parameters.AddWithValue("@Image", id + fileExt);
                        fulImage.SaveAs(Server.MapPath("~/img/products/" + id + fileExt));
                    }

                    else
                    {
                        com3.Parameters.AddWithValue("@Image", DBNull.Value);
                    }

                    com3.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                    com3.ExecuteNonQuery();
                    con.Close();
                }

                txtPName.Text = "";
                txtDescription.Text = "";
                chHasVariant.Checked = true;
                
                GetProducts();

                pnlShowAddProd.Visible = false;
                lblSuccessAddVar.Visible = false;
                lblSuccessAdd.Visible = true;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Product successfully added! Add a variant?');", true);
            }
        }
    }


    protected void btnAddVariant_Click(object sender, EventArgs e)
    {
        if (txtColor.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Enter color type of variant. Try again.');", true);
        }

        else
        {
            if (ddlProduct.SelectedValue == "")
            {
                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = false;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                            "alert('Please select a product to add a variant.')", true);
            }

            else
            {
                con.Open();
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandText = "INSERT INTO ProductDetails (ProductID, Color, Status, Image, DateAdded) VALUES (@ProductID, @Color, @Status, @Image, @DateAdded)";
                com.Parameters.AddWithValue("@ProductID", ddlProduct.SelectedValue);
                com.Parameters.AddWithValue("@Color", txtColor.Text);
                com.Parameters.AddWithValue("@Status", "Active");

                string fileExt = Path.GetExtension(fulImage.FileName);
                string id = Guid.NewGuid().ToString();
                com.Parameters.AddWithValue("@Image", id + fileExt);
                fulImage.SaveAs(Server.MapPath("~/img/products/" + id + fileExt));

                com.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                com.ExecuteNonQuery();
                con.Close();

                txtColor.Text = "";

                GetProducts();

                pnlShowAddVar.Visible = false;
                lblSuccessAdd.Visible = false;
                lblSuccessAddVar.Visible = true;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Product variant successfully added!');", true);
            }
        }
    }

    protected void btnHideAddNew_Click(object sender, EventArgs e)
    {
        lblSuccessAdd.Visible = false;
        lblSuccessAddVar.Visible = false;
        pnlShowAddProd.Visible = false;
    }

    protected void btnHideVariant_Click(object sender, EventArgs e)
    {
        lblSuccessAdd.Visible = false;
        lblSuccessAddVar.Visible = false;
        pnlShowAddVar.Visible = false;
    }
}