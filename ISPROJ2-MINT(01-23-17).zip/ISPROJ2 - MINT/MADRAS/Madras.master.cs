﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class MADRAS_Madras : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (!IsPostBack)
            {
                getInfo();

            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }

        if (Session["typeid"] == null)
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void getInfo()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT FirstName + ' ' + LastName FROM Users WHERE UserID=@UserID";
        com.Parameters.AddWithValue("@UserID", Session["userid"].ToString());
        ltName.Text = (string)com.ExecuteScalar();
        ltName1.Text = (string)com.ExecuteScalar();
        con.Close();
    }
}
