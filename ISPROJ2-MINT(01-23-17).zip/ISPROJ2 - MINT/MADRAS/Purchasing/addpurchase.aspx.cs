﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

public partial class MADRAS_Purchasing_addpurchase : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    List<int> purchaseDetailsID = new List<int>();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (!IsPostBack)
            {
                GetSuppliers();
                purchaseDetailsID.Add(1);
                purchaseDetailsID.Add(2);
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetSuppliers()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT SupplierID, CompanyName FROM Suppliers WHERE Status=@Status";
        com.Parameters.AddWithValue("@Status", "Active");
        SqlDataReader dr = com.ExecuteReader();
        ddlSuppliers.DataSource = dr;
        ddlSuppliers.DataTextField = "CompanyName";
        ddlSuppliers.DataValueField = "SupplierID";
        ddlSuppliers.DataBind();
        con.Close();

        ddlSuppliers.Items.Insert(0, new ListItem("Select a supplier...", ""));
    }

    void GetSupplierItems(int id)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT md.MDetailsID, rm.MaterialName, md.Image, si.PurchasePrice, md.Color FROM SupplierItems si INNER JOIN " +
            "RawMaterials rm ON si.MaterialID=rm.MaterialID INNER JOIN MaterialDetails md ON rm.MaterialID=md.MaterialID " +
            "INNER JOIN Suppliers s ON si.SupplierID=s.SupplierID WHERE si.SupplierID=@SupplierID";
        com.Parameters.AddWithValue("@SupplierID", id);

        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "SupplierItems");
        lvSupplierItems.DataSource = ds;
        lvSupplierItems.DataBind();
        con.Close();
    }

    void CreatePurchase(int id)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "INSERT INTO Purchases VALUES (@SupplierID, @TotalAmount, @Balance, @DatePurchased, @DateAccepted, @DatePaid, " +
                        "@DateDelivered, @DateReceived, @PaymentRef, @Status); SELECT TOP 1 PurchaseID FROM Purchases ORDER BY PurchaseID DESC;";
        com.Parameters.AddWithValue("@SupplierID", id);
        com.Parameters.AddWithValue("@TotalAmount", DBNull.Value);
        com.Parameters.AddWithValue("@Balance", DBNull.Value);
        com.Parameters.AddWithValue("@DatePurchased", DBNull.Value);
        com.Parameters.AddWithValue("@DateAccepted", DBNull.Value);
        com.Parameters.AddWithValue("@DatePaid", DBNull.Value);
        com.Parameters.AddWithValue("@DateDelivered", DBNull.Value);
        com.Parameters.AddWithValue("@DateReceived", DBNull.Value);
        com.Parameters.AddWithValue("@PaymentRef", DBNull.Value);
        com.Parameters.AddWithValue("@Status", "Draft");

        Session["purchaseid"] = com.ExecuteScalar().ToString();

        con.Close();
    }

    void AddtoCart(int purID, int mdetailID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "INSERT INTO PurchaseDetails VALUES (@PurchaseID, @MDetailsID, @QtyPurchased, @Amount)";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        com.Parameters.AddWithValue("@MDetailsID", mdetailID);
        com.Parameters.AddWithValue("@QtyPurchased", DBNull.Value);
        com.Parameters.AddWithValue("@Amount", DBNull.Value);
        com.ExecuteNonQuery();
        con.Close();
    }

    int GetPurDetailsID(int purID, int mdetailID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT PurDetailsID FROM PurchaseDetails WHERE PurchaseID=@PurchaseID AND MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        com.Parameters.AddWithValue("@MDetailsID", mdetailID);
        int pDetails = (int)com.ExecuteScalar();
        con.Close();

        return pDetails;
    }

    decimal GetPrice(int supplierID, int mdetailID)
    {
        decimal price = 0;
        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT si.PurchasePrice FROM SupplierItems si INNER JOIN MaterialDetails md ON si.MaterialID=md.MaterialID " +
                        "WHERE si.SupplierID=@SupplierID AND md.MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@SupplierID", supplierID);
        com.Parameters.AddWithValue("@MDetailsID", mdetailID);
        price = (decimal)com.ExecuteScalar();

        con.Close();

        return price;
    }

    decimal UpdateCart(int purID, int mdetailID, int qtyPurchased)
    {
        decimal amount = qtyPurchased * GetPrice(int.Parse(ddlSuppliers.SelectedValue), mdetailID);

        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE PurchaseDetails SET QtyPurchased=@QtyPurchased, Amount=@Amount WHERE PurchaseID=@PurchaseID AND MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        com.Parameters.AddWithValue("@MDetailsID", mdetailID);
        com.Parameters.AddWithValue("@QtyPurchased", qtyPurchased);
        com.Parameters.AddWithValue("@Amount", amount);
        com.ExecuteNonQuery();
        con.Close();

        return amount;
    }

    void checkQty(int purID)
    {
        foreach (var value in purchaseDetailsID)
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT QtyPurchased FROM PurchaseDetails WHERE PurDetailsID=@PurDetailsID AND PurchaseID=@PurchaseID";
            com.Parameters.AddWithValue("@PurchaseID", purID);
            com.Parameters.AddWithValue("@PurDetailsID", value);

            try
            {
                int qty = (int)com.ExecuteScalar();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                        "alert('Please input quantity.');", true);
            }
        }
    }

    int CountItem(int purID)
    {
        int count = 0;

        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT COUNT(PurchaseID) FROM PurchaseDetails WHERE PurchaseID=@PurchaseID";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        count = (int)com.ExecuteScalar();
        con.Close();

        return count;
    }

    void GetTotal(int purID)
    {
        decimal total = 0;

        con.Open();

        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT SUM(Amount) FROM PurchaseDetails WHERE PurchaseID=@PurchaseID";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        object data = com.ExecuteScalar();
        if (data == null)
        {
            total = 0;
        }
        else
        {
            total = (decimal)com.ExecuteScalar();
        }

        con.Close();

        ltTotal.Text = total.ToString("#,###.00");
    }

    void DeletePurchase(int purID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "DELETE FROM PurchaseDetails WHERE PurchaseID=@PurchaseID; DELETE FROM Purchases WHERE PurchaseID=@PurchaseID;";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        com.ExecuteNonQuery();
        con.Close();

        Session["purchaseid"] = null;

        ltTotal.Text = null;
    }

    void DeleteItem(int purID, int mdetailID)
    {
        decimal amount = 0;
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT Amount FROM PurchaseDetails WHERE PurchaseID=@PurchaseID AND MDetailsID=@MDetailsID";
        com.Parameters.AddWithValue("@PurchaseID", purID);
        com.Parameters.AddWithValue("@MDetailsID", mdetailID);

        try
        {
            amount = (decimal)com.ExecuteScalar();
        }

        catch
        {
            amount = 0;
        }

        decimal total = decimal.TryParse(ltTotal.Text, out total) ? total : 0;
        amount = total - amount;
        con.Close();
        ltTotal.Text = amount.ToString("#,###.00");

        con.Open();
        SqlCommand com2 = new SqlCommand();
        com2.Connection = con;
        com2.CommandText = "DELETE FROM PurchaseDetails WHERE PurchaseID=@PurchaseID AND MDetailsID=@MDetailsID";
        com2.Parameters.AddWithValue("@PurchaseID", purID);
        com2.Parameters.AddWithValue("@MDetailsID", mdetailID);
        com2.ExecuteNonQuery();
        con.Close();
    }

    protected void ddlSuppliers_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSuppliers.SelectedValue != "")
        {
            int supplierID = int.TryParse(ddlSuppliers.SelectedValue, out supplierID) ? supplierID : 0;
            GetSupplierItems(supplierID);

            pnlMaterials.Visible = true;
            ddlSuppliers.Enabled = false;
            ddlSuppliers.CssClass = "form-control";

            CreatePurchase(supplierID);
        }

        else
        {
            pnlMaterials.Visible = false;
        }
    }

    protected void lvSupplierItems_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        Literal ltMDetailsID = (Literal)e.Item.FindControl("ltMDetailsID");
        Panel pnlDataQty = (Panel)e.Item.FindControl("pnlDataQty");
        Literal ltAmount = (Literal)e.Item.FindControl("ltAmount");
        TextBox txtQty = (TextBox)e.Item.FindControl("txtQty");
        LinkButton btnChoose = (LinkButton)e.Item.FindControl("btnChoose");
        LinkButton btnCompute = (LinkButton)e.Item.FindControl("btnCompute");
        LinkButton btnDelete = (LinkButton)e.Item.FindControl("btnDelete");

        int purchaseID = 0;

        try
        {
            purchaseID = int.Parse(Session["purchaseid"].ToString());
        }

        catch
        {
            Response.Redirect("addpurchase.aspx");
        }

        if (e.CommandName == "choose")
        {
            AddtoCart(purchaseID, int.Parse(ltMDetailsID.Text));

            purchaseDetailsID.Add(GetPurDetailsID(purchaseID, int.Parse(ltMDetailsID.Text)));

            pnlHeadQty.Visible = true;
            pnlDataQty.Visible = true;
            btnAdd.Visible = true;
            btnCompute.Visible = true;
            btnDelete.Visible = true;
            btnChoose.Visible = false;
        }

        else if (e.CommandName == "compute")
        {
            if (txtQty.Text != "")
            {
                checkQty(purchaseID);

                ltAmount.Text = UpdateCart(purchaseID, int.Parse(ltMDetailsID.Text), int.Parse(txtQty.Text)).ToString();
                GetTotal(purchaseID);
                pnlTotal.Visible = true;
            }

            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                        "alert('Please input quantity.');", true);
            }
        }

        else if (e.CommandName == "remove")
        {
            foreach (var value in purchaseDetailsID)
            {
                if (value == GetPurDetailsID(purchaseID, int.Parse(ltMDetailsID.Text)))
                {
                    purchaseDetailsID.Remove(value);
                }

                else
                {
                    continue;
                }
            }

            DeleteItem(purchaseID, int.Parse(ltMDetailsID.Text));

            if (CountItem(purchaseID) == 0)
            {
                ltTotal.Text = null;
                pnlTotal.Visible = false;
                pnlHeadQty.Visible = false;
            }

            pnlDataQty.Visible = false;
            btnAdd.Visible = false;
            btnCompute.Visible = false;
            btnDelete.Visible = false;
            btnChoose.Visible = true;
            txtQty.Text = null;
            ltAmount.Text = null;
        }
    }


    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //checkQty(int.Parse(Session["purchaseid"].ToString()));

        foreach (var value in purchaseDetailsID)
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT QtyPurchased FROM PurchaseDetails WHERE PurDetailsID=@PurDetailsID AND PurchaseID=@PurchaseID";
            com.Parameters.AddWithValue("@PurchaseID", Session["purchaseid"].ToString());
            com.Parameters.AddWithValue("@PurDetailsID", value);

            try
            {
                int qty = (int)com.ExecuteScalar();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                        "alert('Please input quantity.');", true);
            }
        }

        con.Open();
        SqlCommand com2 = new SqlCommand();
        com2.Connection = con;
        com2.CommandText = "UPDATE Purchases SET TotalAmount=@TotalAmount, Balance=@Balance, DatePurchased=@DatePurchased, Status=@Status WHERE PurchaseID=@PurchaseID";
        com2.Parameters.AddWithValue("@PurchaseID", Session["purchaseid"].ToString());
        com2.Parameters.AddWithValue("@TotalAmount", ltTotal.Text);
        com2.Parameters.AddWithValue("@Balance", ltTotal.Text);
        com2.Parameters.AddWithValue("@DatePurchased", DateTime.Now);
        com2.Parameters.AddWithValue("@Status", "Ordered");
        com2.ExecuteNonQuery();
        con.Close();

        con.Open();
        SqlCommand com3 = new SqlCommand();
        com3.Connection = con;
        com3.CommandText = "SELECT CompanyName, ContactPerson, Email FROM Suppliers WHERE SupplierID=@SupplierID";
        com3.Parameters.AddWithValue("@SupplierID", ddlSuppliers.SelectedValue);

        string email = "";
        string companyName = "";
        string contactPerson = "";

        SqlDataReader dr = com3.ExecuteReader();
        if(dr.HasRows)
        {
            while (dr.Read())
            {
                email = dr["Email"].ToString();
                companyName = dr["CompanyName"].ToString();
                contactPerson = dr["ContactPerson"].ToString();
            }
        }

        con.Close();

        string subject = "Purchase Order - Madras Crownphil Inc.";

        string message = "Good day " + contactPerson + "! Madras Crownphil Inc. would like to purchase items from your company, " + companyName + 
                       ". <br /> Attached below is a soft copy of our purchase order you can download for viewing.<br />" + 
                       "This message is auto-generated by the MINT system. Do not reply.";

        HelpConfig.SendEmail(email, subject, message);

        ddlSuppliers.Enabled = true;
        pnlMaterials.Visible = false;
        btnAdd.Visible = false;
        ltTotal.Text = null;
        pnlTotal.Visible = false;

        GetSuppliers();

        ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                        "alert('Purchase order has been created for " + companyName + ". An email has been sent to the supplier with the attached file of the purchase order. Thank you.');", true);

        Session["purchaseid"] = null;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            DeletePurchase(int.Parse(Session["purchaseid"].ToString()));
        }

        catch (Exception)
        {
            Response.Redirect("addpurchase.aspx");
        }

        ddlSuppliers.Enabled = true;
        pnlHeadQty.Visible = false;
        pnlMaterials.Visible = false;
        btnAdd.Visible = false;

        GetSuppliers();
    }
}