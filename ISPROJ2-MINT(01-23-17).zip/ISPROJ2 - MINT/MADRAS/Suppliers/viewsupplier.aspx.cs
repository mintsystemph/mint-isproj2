﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class MADRAS_Suppliers_viewsupplier : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(HelpConfig.GetCon());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            if (int.Parse(Session["typeid"].ToString()) == 7)
            {
                Response.Redirect("~/Customer/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 2 || int.Parse(Session["typeid"].ToString()) == 3 || 
                    int.Parse(Session["typeid"].ToString()) == 5 || int.Parse(Session["typeid"].ToString()) == 6)
            {
                Response.Redirect("~/Madras/index.aspx");
            }

            else if (int.Parse(Session["typeid"].ToString()) == 1 || int.Parse(Session["typeid"].ToString()) == 4)
            {
                if (!IsPostBack)
                {
                    GetSuppliers();
                }
            }
        }

        else
        {
            Response.Redirect("~/login.aspx");
        }
    }

    void GetSuppliers()
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT SupplierID, CompanyName, ContactPerson, Address, Email, Mobile, Telephone, Debts, DateAdded, DateModified " +
            "FROM Suppliers WHERE Status=@Status";
        com.Parameters.AddWithValue("@Status", "Active");
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "Suppliers");

        lvSuppliers.DataSource = ds;
        lvSuppliers.DataBind();
        con.Close();
    }

    void GetSuppliers(string keyword)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT s.SupplierID, s.CompanyName, s.ContactPerson, s.Address, s.Email, s.Mobile, s.Telephone, s.Debts, " +
            " s.DateAdded, s.DateModified  FROM Suppliers s INNER JOIN " +
            " Categories c ON p.CatID = c.CatID WHERE p.Name LIKE @keyword OR " +
                            "c.Category LIKE @keyword";
        com.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "Products");
        lvSuppliers.DataSource = ds;
        lvSuppliers.DataBind();

        con.Close();
    }

    void GetInfo(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "SELECT SupplierID, CompanyName, ContactPerson, Address, Email, Mobile, Telephone " +
            "FROM Suppliers WHERE SupplierID=@SupplierID";
        com.Parameters.AddWithValue("@SupplierID", ID);

        SqlDataReader dr = com.ExecuteReader();
        if (dr.HasRows)
        {
            while (dr.Read())
            {
                ltSupplierID.Text = dr["SupplierID"].ToString();
                ltOldEmail.Text = dr["Email"].ToString();
                txtCompanyName.Text = dr["CompanyName"].ToString();
                txtEmail.Text = dr["Email"].ToString();
                txtContactPerson.Text = dr["ContactPerson"].ToString();
                txtAddress.Text = dr["Address"].ToString();
                txtMobile.Text = dr["Mobile"].ToString();
                txtTelephone.Text = dr["Telephone"].ToString();
            }
            con.Close();
        }
        else
        {
            con.Close();
            Response.Redirect("viewsupplier.aspx");
        }
    }

    void ArchiveRecord(int ID)
    {
        con.Open();
        SqlCommand com = new SqlCommand();
        com.Connection = con;
        com.CommandText = "UPDATE Suppliers SET Status=@Status, DateModified=@DateModified WHERE SupplierID=@SupplierID";
        com.Parameters.AddWithValue("@MaterialID", ID);
        com.Parameters.AddWithValue("@Status", "Inactive");
        com.Parameters.AddWithValue("@DateModified", DateTime.Now);
        com.ExecuteNonQuery();

        con.Close();
    }

    protected void lvSuppliers_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int id = int.Parse(e.CommandArgument.ToString());

        if (e.CommandName == "modify")
        {
            GetInfo(id);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "myModal", "showPopup();", true);

        }

        if (e.CommandName == "remove")
        {
            ArchiveRecord(id);
            GetSuppliers();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                    "alert('Supplier was removed successfully!');", true);
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (txtCompanyName.Text == "" || txtEmail.Text == "" || txtContactPerson.Text == "" || txtAddress.Text == "" || txtMobile.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Please fill out the necessary details.');", true);
        }

        else
        {
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandText = "SELECT Email FROM Suppliers WHERE Email=@Email";
            com.Parameters.AddWithValue("@Email", txtEmail.Text);

            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                if (txtEmail.Text != ltOldEmail.Text)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Email address is already existing. Try again.');", true);
                }

                con.Close();
            }

            else
            {
                con.Close();

                con.Open();
                SqlCommand com2 = new SqlCommand();
                com2.Connection = con;
                com2.CommandText = "SELECT Mobile FROM Suppliers WHERE Mobile=@Mobile";
                com2.Parameters.AddWithValue("@Mobile", txtMobile.Text);

                SqlDataReader dr2 = com2.ExecuteReader();
                if (dr2.HasRows)
                {
                    if (txtEmail.Text != ltOldEmail.Text)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                    "alert('Mobile number is already used. Try again.');", true);
                    }

                    con.Close();
                }
            }
            
            if (txtTelephone.Text == "")
            {
                txtTelephone.Text = DBNull.Value.ToString();
            }

            con.Close();

            if (ltOldEmail.Text != txtEmail.Text)
            {
                string subject = "Supplier Email Changed";
                string uniqueKey = "S" + HelpConfig.randomizer() + DateTime.Now.ToString("yyyyMMdd");

                string message = "Hello " + txtContactPerson.Text + ", " + txtCompanyName.Text + " has changed its email address linked to Madras Crownphil Inc. <br />" +
                                        "Please click to this <a href='" + Request.Url.GetLeftPart(UriPartial.Authority) + Request.ApplicationPath +
                                        @"confirmsupplier.aspx?uk=" + uniqueKey + "'>link</a> to confirm and verify your email address.<br />" +
                                        "This is a one-time link. It cannot be opened again once it has been clicked. Thank you. <br /><br />" +
                                        "This message is auto-generated by the MINT system. Do not reply.";

                HelpConfig.SendEmail(txtEmail.Text, subject, message);

                con.Open();
                SqlCommand com4 = new SqlCommand();
                com4.Connection = con;
                com4.CommandText = "INSERT INTO NotifLink VALUES (@UserID, @SupplierID, @UniqueKey, @NotifType, @Subject, @Message, @Status, @DateAdded, @DateClicked)";
                com4.Parameters.AddWithValue("@UserID", DBNull.Value);
                com4.Parameters.AddWithValue("@SupplierID", ltSupplierID.Text);
                com4.Parameters.AddWithValue("@UniqueKey", uniqueKey);
                com4.Parameters.AddWithValue("@NotifType", "Registration");
                com4.Parameters.AddWithValue("@Subject", subject);
                com4.Parameters.AddWithValue("@Message", message);
                com4.Parameters.AddWithValue("@Status", "Unclicked");
                com4.Parameters.AddWithValue("@DateAdded", DateTime.Now);
                com4.Parameters.AddWithValue("@DateClicked", DBNull.Value);
                com4.ExecuteNonQuery();

                con.Close();

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Notify",
                        "alert('Supplier email has been updated! An email has been sent to the supplier to confirm the email address. Inform the supplier immediately. Thank you.');", true);
            }

            con.Open();
            SqlCommand com3 = new SqlCommand();
            com3.Connection = con;
            com3.CommandText = "UPDATE Suppliers SET CompanyName=@CompanyName, ContactPerson=@ContactPerson, Address=@Address, Email=@Email, Mobile=@Mobile, Telephone=@Telephone, DateModified=@DateModified WHERE SupplierID=@SupplierID";
            com3.Parameters.AddWithValue("@SupplierID", ltSupplierID.Text);
            com3.Parameters.AddWithValue("@CompanyName", txtCompanyName.Text);
            com3.Parameters.AddWithValue("@ContactPerson", txtContactPerson.Text);
            com3.Parameters.AddWithValue("@Address", txtAddress.Text);
            com3.Parameters.AddWithValue("@Email", txtEmail.Text);
            com3.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            com3.Parameters.AddWithValue("@Telephone", txtTelephone.Text);
            com3.Parameters.AddWithValue("@DateModified", DateTime.Now);
            com3.ExecuteNonQuery();

            con.Close();

            GetSuppliers();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Alert",
                                "alert('Supplier details were updated successfully!');", true);
        }
    }
}